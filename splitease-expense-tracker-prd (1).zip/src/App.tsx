import { useEffect, useMemo, useRef, useState } from "react";

type Participant = {
  id: string;
  name: string;
  email?: string;
  color: string;
};

type Expense = {
  id: string;
  description: string;
  amount: number;
  date: string; // yyyy-mm-dd
  paidById: string;
  splitMethod: "equal" | "percentage";
  includedIds: string[]; // for equal
  splits?: Record<string, number>; // participantId -> percentage
  createdAt: number;
};

type LedgerEntry = {
  debtorId: string;
  creditorId: string;
  amount: number;
};

const PARTICIPANT_PALETTE = [
  "#2962ff", "#0fa56b", "#7c3aed", "#d97746", "#0ea5e9", "#e5484d",
  "#8b5cf6", "#059669", "#d9468f", "#2563eb", "#14b8a6", "#f59e0b"
];

const uid = () => Math.random().toString(36).slice(2,9);

function initials(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0,2).toUpperCase();
  return (parts[0][0] + parts[parts.length-1][0]).toUpperCase();
}

function todayISO() {
  return new Date().toISOString().slice(0,10);
}

function fmtMoney(n: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(n);
}

function round2(n:number){ return Math.round(n*100)/100; }

/** ===== server-side logic (in-process) ===== */
// splitCalculator.ts
function calculateRawBalances(participants: Participant[], expenses: Expense[]) : Record<string, number> {
  const raw: Record<string, number> = {};
  participants.forEach(p => raw[p.id] = 0);
  for(const exp of expenses){
    if(!raw[exp.paidById] && raw[exp.paidById] !== 0) raw[exp.paidById] = 0;
    raw[exp.paidById] = round2((raw[exp.paidById] ?? 0) + exp.amount);

    if(exp.splitMethod === "equal"){
      const list = exp.includedIds.filter(id => participants.some(pp=>pp.id===id));
      if(list.length === 0) continue;
      const per = round2(exp.amount / list.length);
      // adjust last item to fix rounding drift
      let distributed = 0;
      list.forEach((pid, idx) => {
        if(!raw[pid] && raw[pid] !== 0) raw[pid] = 0;
        const share = idx === list.length-1 ? round2(exp.amount - distributed) : per;
        distributed += share;
        raw[pid] = round2(raw[pid] - share);
      });
    } else {
      const splits = exp.splits ?? {};
      Object.entries(splits).forEach(([pid, pct])=>{
        if(!participants.find(pp => pp.id===pid)) return;
        if(!raw[pid] && raw[pid] !== 0) raw[pid] = 0;
        const share = round2(exp.amount * (pct/100));
        raw[pid] = round2(raw[pid] - share);
      });
    }
  }
  // final clean rounding
  Object.keys(raw).forEach(k => raw[k] = round2(raw[k]));
  return raw;
}

// debtMinimizer.ts
function minimizeDebts(rawBalances: Record<string, number>): LedgerEntry[] {
  const creditors: {id:string, amt:number}[] = [];
  const debtors: {id:string, amt:number}[] = [];
  Object.entries(rawBalances).forEach(([id, bal])=>{
    const n = round2(bal);
    if (n > 0.009) creditors.push({id, amt: n});
    else if (n < -0.009) debtors.push({id, amt: n}); // negative
  });
  creditors.sort((a,b)=> b.amt - a.amt);
  debtors.sort((a,b)=> a.amt - b.amt); // most negative first

  const result: LedgerEntry[] = [];
  let i=0, j=0;
  while(i < debtors.length && j < creditors.length){
    const d = debtors[i];
    const c = creditors[j];
    const settle = round2(Math.min(-d.amt, c.amt));
    if(settle > 0.009){
      result.push({ debtorId: d.id, creditorId: c.id, amount: settle });
      d.amt = round2(d.amt + settle);
      c.amt = round2(c.amt - settle);
    }
    if(Math.abs(d.amt) < 0.01) i++;
    if(c.amt < 0.01) j++;
  }
  return result;
}

function buildBalanceSentences(participants: Participant[], ledger: LedgerEntry[], raw: Record<string, number>) {
  const pMap = Object.fromEntries(participants.map(p=>[p.id,p]));
  const debtorMap: Record<string, LedgerEntry[]> = {};
  ledger.forEach(e => {
    if(!debtorMap[e.debtorId]) debtorMap[e.debtorId] = [];
    debtorMap[e.debtorId].push(e);
  });

  return participants.map(p => {
    const owes = debtorMap[p.id] ?? [];
    if(owes.length === 0){
      const bal = raw[p.id] ?? 0;
      if(Math.abs(bal) < 0.01) return { person: p, text: `${p.name} is settled up`, kind: "even" as const };
      // is creditor (owed)
      return { person: p, text: `${p.name} is owed ${fmtMoney(bal)}`, kind: "owed" as const };
    }
    // produce one combined sentence if multiple
    if(owes.length === 1){
      const e = owes[0];
      return { person: p, text: `${p.name} owes ${pMap[e.creditorId]?.name ?? "Someone"} ${fmtMoney(e.amount)}`, kind: "owes" as const, entry: e };
    }
    // multi
    const multi = owes.map(e => `${pMap[e.creditorId]?.name ?? "Someone"} ${fmtMoney(e.amount)}`).join(" + ");
    return { person: p, text: `${p.name} owes ${multi}`, kind: "owes" as const };
  });
}
/** ===== end server logic ===== */

function PercentRing({ total }:{ total:number }) {
  const clamped = Math.max(0, Math.min(130, total));
  const pct = clamped / 100;
  const r = 29;
  const c = 2*Math.PI*r;
  const dash = c * pct;
  const ok = total >= 99.99 && total <= 100.01;
  const over = total > 100.01;
  const stroke = ok ? "#0fa56b" : over ? "#e5484d" : "#2962ff";
  const bgStroke = "#e7eaf3";
  return (
    <div className="relative w-[84px] h-[84px] shrink-0">
      <svg width="84" height="84" viewBox="0 0 84 84">
        <circle cx="42" cy="42" r={r} fill="none" stroke={bgStroke} strokeWidth="6"/>
        <circle
          cx="42" cy="42" r={r} fill="none"
          stroke={stroke}
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${c}`}
          transform="rotate(-90 42 42)"
          style={{ transition: "stroke-dasharray .22s ease, stroke .18s ease"}}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="font-mono text-[17px] leading-5 text-[#141821] font-[500]">{Math.round(total)}<span className="text-[11px] text-[#7b8296]">%</span></div>
        <div className="text-[10px] font-ui font-[600] tracking-wider"
          style={{ color: ok ? "#0fa56b" : over ? "#e5484d" : "#6d7487" }}
        >
          {ok ? "READY ✓" : over ? "OVER" : "/ 100"}
        </div>
      </div>
    </div>
  );
}

export default function App(){
  // GROUP + PARTICIPANTS
  const [groupName, setGroupName] = useState("Bangkok Weekenders");
  const [editingGroup, setEditingGroup] = useState(false);
  const groupInputRef = useRef<HTMLInputElement>(null);

  const initialParticipants: Participant[] = [
    { id: "p1", name: "Amina Okoro", email: "amina@okoro.io", color: PARTICIPANT_PALETTE[0] },
    { id: "p2", name: "Rahul Sen", email: "rahul.sen@mail.com", color: PARTICIPANT_PALETTE[2] },
    { id: "p3", name: "Sneha Patil", email: "", color: PARTICIPANT_PALETTE[5] },
  ];

  const [participants, setParticipants] = useState<Participant[]>(()=>{
    const ls = localStorage.getItem("splitease_participants_v3");
    if(ls){ try { return JSON.parse(ls);} catch{} }
    return initialParticipants;
  });
  const [expenses, setExpenses] = useState<Expense[]>(()=>{
    const ls = localStorage.getItem("splitease_expenses_v3");
    if(ls){ try { return JSON.parse(ls);} catch{} }
    return [
      {
        id: "e1",
        description: "Airport dinner — ramen",
        amount: 74.5,
        date: todayISO(),
        paidById: "p3",
        splitMethod: "equal",
        includedIds: ["p1","p2","p3"],
        createdAt: Date.now()-3600000*9
      },
      {
        id: "e2",
        description: "Scooter rental day 2",
        amount: 38,
        date: todayISO(),
        paidById: "p1",
        splitMethod: "percentage",
        includedIds: [],
        splits: { p1: 50, p2: 30, p3: 20 },
        createdAt: Date.now()-3600000*4
      }
    ] as Expense[];
  });

  useEffect(()=>{ localStorage.setItem("splitease_participants_v3", JSON.stringify(participants)); },[participants]);
  useEffect(()=>{ localStorage.setItem("splitease_expenses_v3", JSON.stringify(expenses)); },[expenses]);

  // participant modal state
  const [pModalOpen, setPModalOpen] = useState(false);
  const [pEditing, setPEditing] = useState<Participant|null>(null);
  const [pName, setPName] = useState("");
  const [pEmail, setPEmail] = useState("");
  const pNameErr = useMemo(()=>{
    if(!pName.trim()) return "";
    const dup = participants.find(pp => pp.name.toLowerCase().trim() === pName.toLowerCase().trim() && pp.id !== pEditing?.id);
    if(dup) return "A participant with this name already exists.";
    return "";
  }, [pName, participants, pEditing]);

  function openAddParticipant(){
    setPEditing(null);
    setPName("");
    setPEmail("");
    setPModalOpen(true);
  }
  function openEditParticipant(p:Participant){
    setPEditing(p);
    setPName(p.name);
    setPEmail(p.email||"");
    setPModalOpen(true);
  }
  function saveParticipant(){
    const name = pName.trim();
    if(!name || pNameErr) return;
    if(pEditing){
      setParticipants(ps => ps.map(x=> x.id===pEditing.id ? { ...x, name, email: pEmail.trim()||undefined } : x));
    } else {
      const usedColors = participants.map(p=>p.color);
      const color = PARTICIPANT_PALETTE.find(c=>!usedColors.includes(c)) ?? PARTICIPANT_PALETTE[participants.length % PARTICIPANT_PALETTE.length];
      setParticipants(ps => [...ps, { id: uid(), name, email: pEmail.trim()||undefined, color }]);
    }
    setPModalOpen(false);
  }
  function removeParticipant(id:string){
    // disallow removal if they've expenses as payer? We allow, but will filter out from balances calc.
    if(participants.length <= 2){
      alert("You need at least 2 participants in a group.");
      return;
    }
    if(!confirm("Remove this participant? Existing expenses will still reference them.")) return;
    setParticipants(ps => ps.filter(p=>p.id!==id));
  }

  // --- expense form ---
  const [desc, setDesc] = useState("");
  const [amt, setAmt] = useState("");
  const [date, setDate] = useState(todayISO());
  const [paidBy, setPaidBy] = useState<string>(participants[0]?.id ?? "");
  const [splitMethod, setSplitMethod] = useState<"equal"|"percentage">("percentage");

  // equal
  const [equalIncluded, setEqualIncluded] = useState<Record<string, boolean>>({});
  // percentage
  const [pctMap, setPctMap] = useState<Record<string, number>>({});

  // initialize checkboxes / percentages when participants change
  useEffect(()=>{
    const incl: Record<string,boolean> = {};
    participants.forEach(p=> incl[p.id] = equalIncluded[p.id] ?? true);
    setEqualIncluded(incl);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [participants.map(p=>p.id).join(",")]);

  useEffect(()=>{
    if(participants.length===0) return;
    if(!paidBy || !participants.find(p=>p.id===paidBy)) setPaidBy(participants[0].id);
  }, [participants, paidBy]);

  // reset pct map when participants list changes or switch to percentage
  useEffect(()=>{
    if(splitMethod!=="percentage") return;
    setPctMap(prev=>{
      const n: Record<string, number> = {};
      participants.forEach(p=>{
        n[p.id] = typeof prev[p.id]==="number" ? prev[p.id] : 0;
      });
      const total = Object.values(n).reduce((a,b)=>a+b,0);
      if(total===0 && participants.length>0){
        // distribute evenly
        const base = Math.floor(100 / participants.length);
        let rest = 100 - base*participants.length;
        participants.forEach((p, i)=>{
          n[p.id] = base + (i < rest ? 1 : 0);
        });
      }
      return n;
    });
  }, [participants.map(p=>p.id).join(","), splitMethod]);

  const pctTotal = useMemo(()=> Object.values(pctMap).reduce((a,b)=>a+Number(b||0),0), [pctMap]);
  const pctValid = pctTotal >= 99.99 && pctTotal <= 100.01;

  const amountNum = parseFloat(amt);
  const amountValid = amountNum > 0;
  const descValid = desc.trim().length >= 2;
  const canCreateExpense = participants.length >= 2 &&
    descValid && amountValid && paidBy &&
    (splitMethod==="equal"
      ? Object.values(equalIncluded).filter(Boolean).length >= 1
      : pctValid);

  function rebalancePct(changedId:string, newVal:number){
    // Simple: set value, do NOT auto-redistribute; user controls total.
    setPctMap(m => ({ ...m, [changedId]: Math.max(0, Math.min(100, Math.round(newVal))) }));
  }

  function distributeEvenly(){
    const n = participants.length;
    if(!n) return;
    const base = Math.floor(100/n);
    let rem = 100 - base*n;
    const out: Record<string, number> = {};
    participants.forEach((p, i)=>{
      out[p.id] = base + (i < rem ? 1 : 0);
    });
    setPctMap(out);
  }

  function submitExpense(){
    if(!canCreateExpense) return;
    const exp: Expense = {
      id: uid(),
      description: desc.trim(),
      amount: round2(amountNum),
      date,
      paidById: paidBy,
      splitMethod,
      includedIds: splitMethod==="equal"
        ? participants.filter(p=>equalIncluded[p.id]).map(p=>p.id)
        : [],
      splits: splitMethod==="percentage" ? { ...pctMap } : undefined,
      createdAt: Date.now()
    };
    setExpenses(e=>[exp, ...e]);
    // reset form
    setDesc("");
    setAmt("");
    setDate(todayISO());
    distributeEvenly();
    // toast
    showToast("Expense added");
  }

  // calculations (server simulate)
  const rawBalances = useMemo(()=> calculateRawBalances(participants, expenses), [participants, expenses]);
  const ledger = useMemo(()=> minimizeDebts(rawBalances), [rawBalances]);
  const sentenceRows = useMemo(()=> buildBalanceSentences(participants, ledger, rawBalances), [participants, ledger, rawBalances]);

  const totalSpent = useMemo(()=> round2(expenses.reduce((s,e)=>s+e.amount,0)), [expenses]);
  const perPersonAvg = participants.length ? round2(totalSpent / participants.length) : 0;

  // toast
  const [toast, setToast] = useState<string|null>(null);
  function showToast(msg:string){
    setToast(msg);
    setTimeout(()=>setToast(null), 2100);
  }

  const pMap = useMemo(()=> Object.fromEntries(participants.map(p=>[p.id,p])), [participants]);

  return (
    <div className="min-h-screen bg-[#fafafa] text-[#171b23] font-body">
      {/* top thin brand bar */}
      <header className="border-b border-[#eceef2] bg-white/95 backdrop-blur sticky top-0 z-30">
        <div className="mx-auto max-w-[1200px] px-6 md:px-10 py-[18px] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-[11px] bg-[#2962ff] flex items-center justify-center shadow-[0_4px_18px_rgba(41,98,255,.27)]">
              <span className="text-[16px] font-[700] text-white font-ui tracking-tight">S</span>
            </div>
            <div className="leading-tight">
              <div className="font-ui font-[600] text-[17px] tracking-[-0.015em] text-[#1a1e26]">SplitEase</div>
              <div className="text-[11px] text-[#788197] font-[500]">Dynamic group expense engine</div>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-8 text-[13px] font-[500] text-[#5d6679]">
            <span>{participants.length} participants</span>
            <span className="h-3 w-px bg-[#dde2eb]"></span>
            <span>{expenses.length} expenses</span>
            <span className="h-3 w-px bg-[#dde2eb]"></span>
            <span className="text-[#2f3442] font-[600]">{fmtMoney(totalSpent)} total</span>
            <button
              onClick={()=> {
                if(!confirm("Reset all expenses?")) return;
                setExpenses([]);
                showToast("Ledger cleared");
              }}
              className="text-[12px] text-[#8d94a6] hover:text-[#e5484d] transition-colors"
            >Reset ledger</button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1200px] px-6 md:px-10 pt-9 pb-24">
        {/* Group header strip */}
        <div className="flex flex-wrap items-end justify-between gap-4 mb-7">
          <div>
            <div className="text-[11px] uppercase tracking-[0.13em] text-[#8c93a6] font-[600] mb-1">Group</div>
            {!editingGroup ? (
              <div className="flex items-center gap-3">
                <h1 className="font-display text-[32px] md:text-[41px] leading-[1.05] tracking-[-0.022em] text-[#181b22]">{groupName}</h1>
                <button
                  onClick={()=>{ setEditingGroup(true); setTimeout(()=>groupInputRef.current?.focus(), 10); }}
                  className="mt-1 text-[#8d93a6] hover:text-[#2962ff] transition text-[13px]"
                  title="Rename group"
                >
                  ✎
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <input
                  ref={groupInputRef}
                  value={groupName}
                  onChange={e=>setGroupName(e.target.value)}
                  onBlur={()=> setEditingGroup(false)}
                  onKeyDown={e=> { if(e.key==="Enter") setEditingGroup(false);} }
                  className="font-display text-[30px] md:text-[39px] bg-white border border-[#cdd6ef] rounded-xl px-3 py-1 outline-none focus:ring-[3px] focus:ring-[#d7e2ff]"
                />
                <button onClick={()=>setEditingGroup(false)} className="text-[13px] text-[#2962ff] font-[600]">Done</button>
              </div>
            )}
            <div className="mt-2 text-[13.5px] text-[#697185]">
              Add participants, split any way you like. Settlement engine auto-nets debts across any group size.
            </div>
          </div>
          <div className="flex items-center gap-3 text-[12.5px]">
            <div className="px-3 py-[7px] rounded-full bg-[#f1f4fb] text-[#4a556d] border border-[#e1e6f2] font-[500]">
              Avg per person {fmtMoney(perPersonAvg)}
            </div>
            <div className="px-3 py-[7px] rounded-full bg-[#f1faf4] text-[#12734d] border border-[#cfe9db] font-[600]">
              {ledger.length} settlement{ledger.length!==1?"s":""}
            </div>
          </div>
        </div>

        {/* Participant Cards Row */}
        <section className="mb-10">
          <div className="flex items-center justify-between mb-3">
            <div className="text-[12px] font-[650] tracking-[0.07em] uppercase text-[#8a909f]">Participants</div>
            <div className="text-[12px] text-[#8a909f]">{participants.length} active • min 2 to create expense</div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-3">
            {participants.map(p => (
              <div key={p.id}
                className="group bg-white border border-[#e6e8ee] rounded-2xl p-4 shadow-[0_1px_2px_rgba(20,34,60,.04),0_10px_24px_rgba(20,34,60,.04)] hover:shadow-[0_2px_8px_rgba(20,34,60,.045),0_18px_36px_rgba(20,34,60,.065)] transition-all"
              >
                <div className="flex items-start justify-between">
                  <div className="w-11 h-11 rounded-[14px] flex items-center justify-center text-white font-ui font-[600] text-[13px]"
                    style={{ background: p.color }}>
                    {initials(p.name)}
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={()=> openEditParticipant(p)}
                      className="text-[11px] text-[#7c818f] hover:text-[#2962ff] px-[8px] py-[4px] rounded-md hover:bg-[#f2f5ff]"
                    >edit</button>
                    <button
                      onClick={()=> removeParticipant(p.id)}
                      className="text-[11px] text-[#8f8993] hover:text-[#d23342] px-[8px] py-[4px] rounded-md hover:bg-[#fff1f2]"
                    >remove</button>
                  </div>
                </div>
                <div className="mt-3 font-[600] text-[15px] text-[#1d2330]">{p.name}</div>
                <div className="text-[12px] text-[#7b8292] truncate">
                  {p.email || <span className="italic text-[#a2a8b6]">no email</span>}
                </div>
                <div className="mt-3 text-[12px] font-mono">
                  <span className="text-[#8a919f]">bal </span>
                  <span className={ (rawBalances[p.id] ?? 0) >= 0 ? "text-[#11865a]" : "text-[#d23342]" }>
                    {fmtMoney(rawBalances[p.id] ?? 0)}
                  </span>
                </div>
              </div>
            ))}
            {/* Add card */}
            <button
              onClick={openAddParticipant}
              className="min-h-[147px] bg-[#fcfcfd] border-[1.6px] border-dashed border-[#cfd4de] rounded-2xl p-4 flex flex-col items-center justify-center text-center hover:border-[#2962ff] hover:bg-[#f7f9ff] transition-colors"
            >
              <div className="w-10 h-10 rounded-full border border-[#d9deed] flex items-center justify-center text-[#5b6781] text-[20px] mb-2">＋</div>
              <div className="text-[13.5px] font-[560] text-[#444d5f]">Add participant</div>
              <div className="text-[11.5px] text-[#8d94a3] mt-1">name • email optional</div>
            </button>
          </div>
          {participants.length < 2 && (
            <div className="mt-4 text-[13px] text-[#ba631c] bg-[#fff7eb] border border-[#f3d7a8] rounded-xl px-4 py-3">
              You need at least 2 participants before you can create an expense.
            </div>
          )}
        </section>

        {/* Main 2-column */}
        <div className="grid grid-cols-12 gap-6 lg:gap-8 items-start">
          {/* Left: Create expense */}
          <div className="col-span-12 lg:col-span-7">
            <div className="bg-white border border-[#e5e7ee] rounded-[22px] shadow-[0_1px_2px_rgba(23,29,42,.05),0_20px_50px_rgba(23,29,42,.045)]">
              <div className="px-[26px] pt-[24px] pb-[16px] border-b border-[#eef0f4]">
                <div className="text-[11.5px] font-[650] uppercase tracking-[0.09em] text-[#8f97a6]">New bill</div>
                <div className="font-display text-[27px] tracking-[-0.015em] text-[#1a1f2a]">Create expense</div>
              </div>

              <div className="px-[26px] py-[22px] space-y-[20px]">
                {/* desc + amount + date */}
                <div className="grid md:grid-cols-12 gap-4">
                  <div className="md:col-span-7">
                    <label className="block text-[12px] font-[600] text-[#657089] mb-[7px]">Description</label>
                    <input
                      value={desc}
                      onChange={e=>setDesc(e.target.value)}
                      placeholder="e.g. Boat brunch"
                      className="w-full bg-[#f7f8fb] border border-[#dde1e7] rounded-xl px-4 py-[13px] text-[15px] outline-none focus:bg-white focus:border-[#8fb4ff] focus:ring-[3px] focus:ring-[#e7efff] transition-all"
                    />
                  </div>
                  <div className="md:col-span-3">
                    <label className="block text-[12px] font-[600] text-[#657089] mb-[7px]">Amount</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[14px] text-[#8b92a5]">$</span>
                      <input
                        inputMode="decimal"
                        value={amt}
                        onChange={e=> setAmt(e.target.value.replace(/[^0-9.]/g,""))}
                        placeholder="0.00"
                        className="w-full bg-[#f7f8fb] border border-[#dde1e7] rounded-xl pl-7 pr-3 py-[13px] text-[15px] font-mono outline-none focus:bg-white focus:border-[#8fb4ff] focus:ring-[3px] focus:ring-[#e7efff] transition-all"
                      />
                    </div>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-[12px] font-[600] text-[#657089] mb-[7px]">Date</label>
                    <input
                      type="date"
                      value={date}
                      onChange={e=>setDate(e.target.value)}
                      className="w-full bg-[#f7f8fb] border border-[#dde1e7] rounded-xl px-3 py-[13px] text-[13.5px] outline-none focus:bg-white focus:border-[#8fb4ff] focus:ring-[3px] focus:ring-[#e7efff]"
                    />
                  </div>
                </div>

                {/* paid by */}
                <div>
                  <label className="block text-[12px] font-[600] text-[#657089] mb-[7px]">Paid by</label>
                  <div className="flex flex-wrap gap-2">
                    {participants.map(p=>(
                      <button key={p.id}
                        type="button"
                        onClick={()=>setPaidBy(p.id)}
                        className={`px-3 py-[9px] rounded-full border text-[13px] font-[500] flex items-center gap-[9px] transition-all ${paidBy===p.id ? "bg-[#eef2ff] border-[#b6c7ff] text-[#1d46d4]" : "bg-white border-[#dde3ea] text-[#5a6273] hover:border-[#b8c0cc]"}`}
                      >
                        <span className="w-[22px] h-[22px] rounded-full text-[10px] font-[700] text-white flex items-center justify-center" style={{ background:p.color }}>{initials(p.name)}</span>
                        {p.name.split(" ")[0]}
                      </button>
                    ))}
                    {participants.length===0 && <span className="text-[13px] text-[#999]">Add participants first</span>}
                  </div>
                </div>

                {/* split method toggle */}
                <div>
                  <label className="block text-[12px] font-[600] text-[#657089] mb-[7px]">Split method</label>
                  <div className="inline-flex bg-[#f1f3f8] rounded-[14px] p-[4px] border border-[#e2e6ef]">
                    {(["equal","percentage"] as const).map(m=>(
                      <button
                        key={m}
                        type="button"
                        onClick={()=>setSplitMethod(m)}
                        className={`px-4 py-[7px] rounded-[10px] text-[13px] font-[560] capitalize transition-all ${splitMethod===m ? "bg-white shadow-[0_1px_2px_rgba(0,0,0,.06)] text-[#203054]" : "text-[#6f778a] hover:text-[#333b4d]"}`}
                      >
                        {m}
                      </button>
                    ))}
                  </div>
                </div>

                {/* equal split UI */}
                {splitMethod==="equal" && (
                  <div className="bg-[#fafbfe] border border-[#e5e9f5] rounded-[16px] px-4 py-4">
                    <div className="text-[12px] text-[#6d768a] mb-[11px]">Select who shared this expense</div>
                    <div className="flex flex-wrap gap-[9px]">
                      {participants.map(p=>{
                        const on = !!equalIncluded[p.id];
                        return (
                          <button
                            key={p.id}
                            type="button"
                            onClick={()=> setEqualIncluded(s => ({ ...s, [p.id]: !s[p.id] }))}
                            className={`px-3 py-[7px] rounded-full border text-[12.8px] transition ${on ? "bg-white border-[#b9cbff] text-[#2a3b61]" : "bg-[#f3f5f9] border-[#e3e7ef] text-[#788196]"}`}
                          >
                            <span style={{ color: p.color }}>●</span> {p.name.split(" ")[0]}
                          </button>
                        );
                      })}
                    </div>
                    {(() => {
                      const cnt = Object.values(equalIncluded).filter(Boolean).length;
                      const per = amountValid && cnt>0 ? round2(amountNum / cnt) : 0;
                      return (
                        <div className="mt-3 text-[12.5px] text-[#6a7386] font-mono">
                          {cnt>0 ? `${cnt} people • ${fmtMoney(per)} each` : "Select at least one participant"}
                        </div>
                      );
                    })()}
                  </div>
                )}

                {/* percentage split */}
                {splitMethod==="percentage" && (
                  <div className="bg-[#fafbfe] border border-[#e5e9f5] rounded-[16px] px-4 py-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 space-y-[15px]">
                        {participants.map(p=>(
                          <div key={p.id} className="grid grid-cols-12 items-center gap-3">
                            <div className="col-span-5 md:col-span-4 flex items-center gap-2">
                              <span className="w-[11px] h-[11px] rounded-full" style={{ background:p.color }}></span>
                              <span className="text-[13.4px] text-[#2c3445] font-[500] truncate">{p.name.split(" ")[0]}</span>
                            </div>
                            <input
                              type="range"
                              min={0} max={100}
                              value={pctMap[p.id] ?? 0}
                              onChange={e=>rebalancePct(p.id, Number(e.target.value))}
                              className="col-span-5 md:col-span-6"
                              style={{
                                accentColor: p.color
                              }}
                            />
                            <div className="col-span-2 flex items-center justify-end gap-1">
                              <input
                                type="number"
                                min={0} max={100}
                                value={pctMap[p.id] ?? 0}
                                onChange={e=>rebalancePct(p.id, Number(e.target.value))}
                                className={`w-[66px] bg-white border rounded-lg px-2 py-[6px] text-right text-[13px] font-mono ${pctValid ? "border-[#d9dde8]" : "border-[#f1a9a9] bg-[#fff7f7]"}`}
                              />
                              <span className="text-[11px] text-[#9198a8]">%</span>
                            </div>
                          </div>
                        ))}
                        <div className="flex items-center gap-3 pt-1">
                          <button
                            type="button"
                            onClick={distributeEvenly}
                            className="text-[12px] text-[#5970a4] hover:text-[#2962ff]"
                          >distribute evenly</button>
                          <span className="text-[12px] text-[#8e95a5]">•</span>
                          <button
                            type="button"
                            onClick={()=> setPctMap({})}
                            className="text-[12px] text-[#888f9d] hover:text-[#444]"
                          >clear</button>
                        </div>
                      </div>

                      {/* ring */}
                      <PercentRing total={pctTotal}/>
                    </div>

                    <div className={`mt-3 text-[12.5px] font-[500] ${pctValid ? "text-[#14945c]" : pctTotal>100 ? "text-[#d63b3b]" : "text-[#c17b0a]"}`}>
                      {pctValid ? "Perfect — 100% allocated ✓"
                        : pctTotal < 100 ? `${(100-pctTotal).toFixed(0)}% remaining to allocate`
                        : `${(pctTotal-100).toFixed(0)}% over — reduce some sliders`}
                    </div>
                  </div>
                )}

                {/* submit */}
                <div className="pt-2 flex items-center justify-between">
                  <div className="text-[12.5px] text-[#7d8596]">
                    {!descValid && desc.length>0 && "Add a description • "}
                    {!amountValid && amt && "Amount must be > 0 • "}
                    {splitMethod==="percentage" && !pctValid && "Percentages must total 100%"}
                    {canCreateExpense && <span className="text-[#2c805e]">Ready to post</span>}
                  </div>
                  <button
                    onClick={submitExpense}
                    disabled={!canCreateExpense}
                    className={`px-5 py-[11px] rounded-full text-[14px] font-[600] transition-all ${
                      canCreateExpense
                        ? "bg-[#2962ff] text-white shadow-[0_6px_18px_rgba(41,98,255,.26)] hover:bg-[#1f51d9] active:scale-[.99]"
                        : "bg-[#e6e9f0] text-[#9aa3b4] cursor-not-allowed"
                    }`}
                  >
                    Create expense
                  </button>
                </div>
              </div>
            </div>

            {/* Expense ledger */}
            <div className="mt-7 bg-white border border-[#e4e7ee] rounded-[22px] shadow-[0_1px_2px_rgba(23,29,42,.045),0_18px_44px_rgba(23,29,42,.04)]">
              <div className="px-[24px] pt-[20px] pb-[14px] flex items-center justify-between">
                <div>
                  <div className="font-display text-[22px] tracking-[-0.012em] text-[#1d2230]">Expense ledger</div>
                  <div className="text-[12.5px] text-[#747e92]">{expenses.length} entries • {fmtMoney(totalSpent)} total</div>
                </div>
                <button
                  onClick={()=> {
                    if(expenses.length===0) return;
                    if(!confirm("Clear all expenses?")) return;
                    setExpenses([]);
                  }}
                  className="text-[12px] text-[#8c94a7] hover:text-[#444]"
                >clear</button>
              </div>
              <div className="border-t border-[#eef0f4]">
                {expenses.length===0 ? (
                  <div className="px-6 py-10 text-center">
                    <div className="text-[15px] text-[#5b6476] font-[500]">No expenses yet.</div>
                    <div className="text-[13px] text-[#8d95a8] mt-1">Add your first bill above to see settlements update live.</div>
                  </div>
                ) : (
                  <div className="divide-y divide-[#f0f2f6]">
                    {expenses.map(e=>{
                      const payer = pMap[e.paidById];
                      return (
                        <div key={e.id} className="px-[24px] py-[16px] flex items-start justify-between gap-4 hover:bg-[#fcfcfe]">
                          <div className="min-w-0">
                            <div className="font-[560] text-[#1f2430]">{e.description}</div>
                            <div className="text-[12px] text-[#7d8594] mt-[3px] flex flex-wrap items-center gap-2">
                              <span>{e.date}</span>
                              <span className="opacity-40">•</span>
                              <span>paid by <span className="font-[560]" style={{ color: payer?.color }}>{payer?.name?.split(" ")[0] ?? "?"}</span></span>
                              <span className="opacity-40">•</span>
                              <span className="font-[500] text-[#6b7282]">{e.splitMethod}</span>
                            </div>
                            <div className="mt-[8px] flex flex-wrap gap-x-[14px] gap-y-1 text-[11.5px] text-[#6c7586]">
                              {e.splitMethod==="equal"
                                ? e.includedIds.map(id=>(
                                  <span key={id}>
                                    {pMap[id]?.name?.split(" ")[0] ?? "?"}: {fmtMoney(e.amount / (e.includedIds.length||1))}
                                  </span>
                                ))
                                : Object.entries(e.splits ?? {}).map(([id,pct])=>(
                                  <span key={id} style={{ color: pMap[id]?.color }}>
                                    {pMap[id]?.name?.split(" ")[0] ?? "?"} {pct}%
                                  </span>
                                ))
                              }
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <div className="font-mono text-[16px] text-[#1f2531] font-[500]">{fmtMoney(e.amount)}</div>
                            <button
                              onClick={()=> {
                                setExpenses(expenses.filter(x=>x.id !== e.id));
                                showToast("Expense removed");
                              }}
                              className="text-[11.5px] text-[#a2aab8] hover:text-[#cf3d4a] mt-1"
                            >delete</button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right: Settlement board */}
          <div className="col-span-12 lg:col-span-5">
            <div className="bg-white border border-[#e4e7ee] rounded-[22px] shadow-[0_1px_2px_rgba(23,29,42,.045),0_18px_44px_rgba(23,29,42,.042)] overflow-hidden sticky top-[84px]">
              <div className="px-[24px] pt-[22px] pb-[16px] border-b border-[#eef0f4] bg-[linear-gradient(180deg,#ffffff_0%,#fcfdff_100%)]">
                <div className="text-[11px] font-[650] uppercase tracking-[0.095em] text-[#9096a6]">Live settlement</div>
                <div className="font-display text-[26px] tracking-[-0.015em] text-[#1b212d]">Net balances</div>
                <div className="text-[12.5px] text-[#71798a] mt-1">Debt-minimized • server-side calculation</div>
              </div>

              <div className="px-[20px] py-[20px] space-y-[11px] min-h-[200px]">
                {participants.length < 2 ? (
                  <div className="text-[13.5px] text-[#7d8392] py-6 text-center">
                    Add at least two participants to see balances.
                  </div>
                ) : expenses.length === 0 ? (
                  <div className="text-[13.5px] text-[#717889] py-6 text-center">
                    No expenses yet.<br/>
                    <span className="text-[12.5px] text-[#989fad]">Add your first bill to see who owes what.</span>
                  </div>
                ) : (
                  sentenceRows.map((row, i)=>(
                    <div key={row.person.id+"-"+i}
                      className="rounded-[15px] border px-4 py-3 bg-[#fafbfe] border-[#e4e8f1] flex items-center gap-[12px] transition-all duration-300"
                      style={{ borderLeftWidth: "4px", borderLeftColor: row.person.color }}
                    >
                      <div
                        className="w-8 h-8 rounded-[10px] flex items-center justify-center text-white text-[11px] font-[700]"
                        style={{ background: row.person.color }}
                      >
                        {initials(row.person.name)}
                      </div>
                      <div className="text-[14px] text-[#273043] font-[500]">
                        {row.text}
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* minimized transfers */}
              <div className="border-t border-[#eef0f4] bg-[#fcfcfe] px-[22px] py-[18px]">
                <div className="text-[12px] font-[640] text-[#7d8391] mb-3">Minimized transfers</div>
                {ledger.length===0 ? (
                  <div className="text-[13px] text-[#70808a]">All settled up 🎉</div>
                ) : (
                  <div className="space-y-[9px]">
                    {ledger.map((l, idx)=>{
                      const d = pMap[l.debtorId];
                      const c = pMap[l.creditorId];
                      return (
                        <div key={idx} className="flex items-center justify-between bg-white border border-[#e5e8ee] rounded-[12px] px-[13px] py-[11px]">
                          <div className="text-[13px] text-[#303846]">
                            <span className="font-[600]">{d?.name ?? "?"}</span>
                            <span className="text-[#8f97a8] mx-[7px]">→</span>
                            <span className="font-[600]">{c?.name ?? "?"}</span>
                          </div>
                          <div className="font-mono text-[13.5px] text-[#1f2735] font-[560]">{fmtMoney(l.amount)}</div>
                        </div>
                      );
                    })}
                  </div>
                )}
                <div className="mt-4 text-[11.5px] text-[#8f95a5]">
                  Engine: fractional division → raw balances → greedy min-cash-flow. Works for 2…100+ participants.
                </div>
              </div>
            </div>

            {/* small info card */}
            <div className="mt-4 rounded-[18px] border border-[#e5e9f4] bg-[#f8faff] px-[18px] py-[15px] text-[12.5px] text-[#5c667a] leading-relaxed">
              <div className="font-[600] text-[#30405d] mb-1">How settlement works</div>
              Every expense is posted to the “server” (in-memory). Balances: payer gets full credit, each participant is debited their share. Counter-debts are netted, resulting in the smallest possible number of transfers.
            </div>
          </div>
        </div>

        <footer className="mt-14 text-center text-[12px] text-[#959cad]">
          SplitEase • dynamic • {participants.length} participants • {expenses.length} expenses • built for roommates, trips & teams
        </footer>
      </main>

      {/* Participant modal */}
      {pModalOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-[#1b2334]/35 backdrop-blur-sm" onClick={()=>setPModalOpen(false)} />
          <div className="absolute left-1/2 top-[13%] -translate-x-1/2 w-[92%] max-w-[440px] bg-white border border-[#dde2ea] rounded-[22px] shadow-[0_20px_60px_rgba(27,34,53,.16)] p-[22px]">
            <div className="text-[11px] uppercase tracking-[0.095em] text-[#8f96a4] font-[650] mb-1">{pEditing ? "Edit participant" : "New participant"}</div>
            <div className="font-display text-[24px] tracking-[-0.013em] text-[#1b212f] mb-4">
              {pEditing ? "Update details" : "Add to group"}
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-[12px] font-[600] text-[#5f687b] mb-[6px]">Full name</label>
                <input
                  value={pName}
                  onChange={e=>setPName(e.target.value)}
                  placeholder="e.g. Lena Martínez"
                  autoFocus
                  className="w-full border border-[#d8dbe3] rounded-xl px-4 py-[12px] text-[15px] outline-none focus:border-[#9ab8ff] focus:ring-[3px] focus:ring-[#e7efff] bg-[#f7f8fb]"
                />
                {pNameErr && <div className="text-[12px] text-[#d23a3d] mt-[6px]">{pNameErr}</div>}
              </div>
              <div>
                <label className="block text-[12px] font-[600] text-[#5f687b] mb-[6px]">Email <span className="text-[#a8adb8] font-[450]">optional</span></label>
                <input
                  value={pEmail}
                  onChange={e=>setPEmail(e.target.value)}
                  type="email"
                  placeholder="name@email.com"
                  className="w-full border border-[#d8dbe3] rounded-xl px-4 py-[12px] text-[15px] outline-none focus:border-[#9ab8ff] focus:ring-[3px] focus:ring-[#e7efff] bg-[#f7f8fb]"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-6">
              <button onClick={()=> setPModalOpen(false)} className="px-4 py-[10px] rounded-full text-[13.5px] text-[#5a6171] hover:bg-[#f2f4f8]">Cancel</button>
              <button
                onClick={saveParticipant}
                disabled={!pName.trim() || !!pNameErr}
                className={`px-[18px] py-[10px] rounded-full text-[13.5px] font-[600] ${(!pName.trim()||!!pNameErr) ? "bg-[#e7e9ef] text-[#a0a5b2] cursor-not-allowed" : "bg-[#2962ff] text-white shadow-[0_6px_16px_rgba(41,98,255,.26)] hover:bg-[#1c4ed8]"}`}
              >
                {pEditing ? "Save changes" : "Add participant"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* toast */}
      <div className={`fixed z-[60] bottom-6 right-6 transition-all duration-300 ${toast ? "opacity-100 translate-y-0" : "opacity-0 translate-y-3 pointer-events-none"}`}>
        <div className="bg-[#192030] text-white text-[13px] font-[520] px-4 py-[11px] rounded-full shadow-[0_12px_40px_rgba(13,23,48,.28)]">
          {toast}
        </div>
      </div>
    </div>
  );
}